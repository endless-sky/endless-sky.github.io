#define SDL_REVISION "https://github.com/msys2/MINGW-packages@33e5aec9cc5ea15890076bab2469a9d29cc9162d"
#define SDL_REVISION_NUMBER 0

#ifndef SDL_REVISION
#define SDL_REVISION ""
#endif
